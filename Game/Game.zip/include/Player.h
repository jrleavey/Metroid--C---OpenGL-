#ifndef PLAYER_H
#define PLAYER_H

#include "Room.h"  // Include the Room class for collision detection

class Player {
public:
    Player(float x, float y, float size, float speed, float jumpHeight, float gravity);
    void update(float deltaTime, const Room& currentRoom); // Update to include reference to the current room
    void render();
    void moveLeft(float deltaTime, const Room& currentRoom);
    void moveRight(float deltaTime, const Room& currentRoom);
    void jump(float deltaTime, const Room& currentRoom);
    void applyGravity(float deltaTime, const Room& currentRoom);
    bool isOnGround(const Room& currentRoom) const;

private:
    float x, y;  // Player's position
    float size;  // Size of the player (width/height of the square)
    float speed;  // Movement speed
    float jumpHeight;  // Jump height
    float gravity;  // Gravity affecting the player
    bool isJumping;  // State of the player's jump
    float verticalSpeed;  // Current vertical speed

    bool canMoveTo(float newX, float newY, const Room& currentRoom) const; // Helper function to check if the player can move to a new position
};

#endif // PLAYER_H
