#ifndef ROOM_H
#define ROOM_H

#include <vector>

enum CellType {
    OPEN_SPOT,
    BLOCK
};

class Room {
public:
    Room(int width, int height);
    void render() const;
    bool isCellBlocked(int x, int y) const;
    void setTileAsBlocked(int x, int y);
    float getTileSize() const { return tileSize; }

private:
    int width, height;
    float tileSize;
    std::vector<std::vector<CellType>> grid;
    void drawQuad(float left, float bottom) const;
};

#endif // ROOM_H
