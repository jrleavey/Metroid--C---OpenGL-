#define GAME_CPP
#include <windows.h>											// Header File For Windows
#include <stdio.h>												// Header File For Standard Input / Output
#include <stdarg.h>												// Header File For Variable Argument Routines
#include <math.h>												// Header File For Math Operations
#include <gl\gl.h>												// Header File For The OpenGL32 Library
#include <gl\glu.h>												// Header File For The GLu32 Library
#include "glut.h"
#include "baseTypes.h"
#include "openglframework.h"	
#include "gamedefs.h"
#include "collInfo.h"
#include "object.h"
#include "inputmapper.h"
#include "ball.h"
#include "field.h"
#include "random.h"
#include "gameObjects.h"
#include "openGLStuff.h"
#include "StateManager.h"
#include "BallManager.h"
#include "FieldManager.h"
#include "InputManager.h"
#include "SpriteDemoManager.h"
#include "igame.h"
#include "player.h"
#include "Game.h"
#include "Room.h"

Player* player; // Global definition of the Player object
Room* currentRoom; // Global definition of the current Room object

// Define the keyProcess function in Game.cpp
void CGame::keyProcess() {
    if (g_keys->keyDown['A']) {
        player->moveLeft(0.016f, *currentRoom);
    }
    if (g_keys->keyDown['D']) {
        player->moveRight(0.016f, *currentRoom);
    }
    if (g_keys->keyDown[VK_SPACE] && player->isOnGround(*currentRoom)) {
        player->jump(0.016f, *currentRoom);
    }
}


IGame* CreateGame() {
    return new CGame();
}

void DestroyGame(IGame* pGame) {
    delete pGame;
}

const char8_t CGame::mGameTitle[] = "Framework1";

CGame::CGame() {
    currentRoom = new Room(100, 100); // Width: 32 tiles, Height: 24 tiles, Tile size: 32 pixels
    currentRoom->setTileAsBlocked(5, 5); // Set a single tile as impassible
    currentRoom->setTileAsBlocked(6, 5);
    currentRoom->setTileAsBlocked(10, 10);
    currentRoom->setTileAsBlocked(10, 10);
    player = new Player(100.0f, 100.0f, 50.0f, 200.0f, 400.0f, 200.0f);
}

CGame::~CGame() {
    delete player;
    delete currentRoom;
}

bool CGame::Initialize(GL_Window* window, Keys* keys) {
    initOpenGLDrawing(window, keys, 0.0f, 0.0f, 0.0f);
    return true;
}

void CGame::Deinitialize() {
    // Deinitialization logic (if any)
}

void CGame::UpdateFrame(uint32_t milliseconds) {
    if (g_keys->keyDown[VK_ESCAPE]) {
        TerminateApplication(g_window);
    }
    if (g_keys->keyDown[VK_F1]) {
        ToggleFullscreen(g_window);
    }

    float deltaTime = milliseconds / 1000.0f;
    keyProcess();
    player->update(deltaTime, *currentRoom);
    player->applyGravity(deltaTime, *currentRoom);
}

void CGame::DrawScene() {
    startOpenGLDrawing();
    currentRoom->render();
    player->render();
}

void DrawRectangle(float xPos, float yPos, float rectWidth, float rectHeight) {
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_CULL_FACE);
    glBegin(GL_QUADS);
    glColor3ub(0xF3, 0xDE, 0x7A); // Example color
    // ... Rectangle drawing logic
    glEnd();
}