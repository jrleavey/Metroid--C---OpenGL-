#include "Player.h"
#include "Room.h"
#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include "glut.h"
#include "openglframework.h"  
#include "gamedefs.h"
#include "openGLStuff.h"

Player::Player(float x, float y, float size, float speed, float jumpHeight, float gravity)
    : x(x), y(y), size(size), speed(speed), jumpHeight(jumpHeight), gravity(gravity), isJumping(false), verticalSpeed(0) {}

void Player::update(float deltaTime, const Room& currentRoom) {
    // Apply gravity if the player is not on the ground
    applyGravity(deltaTime, currentRoom);

    // Other update logic (if any)
}

void Player::render() {
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_CULL_FACE);
    glBegin(GL_QUADS);
    glColor3f(1.0f, 0.0f, 0.0f); // Set player color (e.g., red)

    // Draw the player as a square (quad)
    glVertex2f(x - size / 2, y - size / 2); // Bottom Left
    glVertex2f(x + size / 2, y - size / 2); // Bottom Right
    glVertex2f(x + size / 2, y + size / 2); // Top Right
    glVertex2f(x - size / 2, y + size / 2); // Top Left

    glEnd();
}

void Player::moveLeft(float deltaTime, const Room& currentRoom) {
    float newX = x - speed * deltaTime;
    if (canMoveTo(newX, y, currentRoom)) {
        x = newX;
    }
}

void Player::moveRight(float deltaTime, const Room& currentRoom) {
    float newX = x + speed * deltaTime;
    if (canMoveTo(newX, y, currentRoom)) {
        x = newX;
    }
}


void Player::jump(float deltaTime, const Room& currentRoom) {
    if (isOnGround(currentRoom) && !isJumping) {
        isJumping = true;
        verticalSpeed = jumpHeight; // Set upward speed
        y += verticalSpeed * deltaTime; // Move up immediately
    }
}

bool Player::isOnGround(const Room& currentRoom) const {
    // Check the tile directly below the player's bottom edge
    int gridX = static_cast<int>(x / currentRoom.getTileSize());
    int gridY = static_cast<int>((y - size / 2) / currentRoom.getTileSize()) - 1; // Directly beneath the player

    // Return true if the tile below is a block or if the player's y is 0 (ground level)
    return (y == 0) || currentRoom.isCellBlocked(gridX, gridY);
}


void Player::applyGravity(float deltaTime, const Room& currentRoom) {
    if (!isOnGround(currentRoom) || isJumping) {
        verticalSpeed -= gravity * deltaTime;
        float potentialY = y + verticalSpeed * deltaTime;

        // Calculate the tile position that the player might move into
        int gridX = static_cast<int>(x / currentRoom.getTileSize()); // Added this line
        int gridY = static_cast<int>((potentialY - size / 2) / currentRoom.getTileSize());

        // If moving to the new position would collide with a block, adjust the y position
        if (!currentRoom.isCellBlocked(gridX, gridY)) {
            y = potentialY;
        }
        else {
            y = (gridY + 1) * currentRoom.getTileSize() + size / 2; // Place player right on top of the block
            isJumping = false;
            verticalSpeed = 0;
        }
    }
}


bool Player::canMoveTo(float newX, float newY, const Room& currentRoom) const {
    int gridX = static_cast<int>(newX / currentRoom.getTileSize());
    int gridY = static_cast<int>((y - size / 2) / currentRoom.getTileSize()); // Check at feet level

    return !currentRoom.isCellBlocked(gridX, gridY);
}
