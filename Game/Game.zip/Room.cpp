#include "Room.h"
#include <Windows.h>
#include <GL/gl.h>

Room::Room(int width, int height) : width(width), height(height), tileSize(32.0f)
{

    grid.resize(height, std::vector<CellType>(width, OPEN_SPOT));

    // Initialize the outer cells as BLOCK and inner cells as OPEN_SPOT
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            if (y == 0 || y == height - 1 || x == 0 || x == width - 1) {
                grid[y][x] = BLOCK; // Walls, floor, and ceiling
            }
        }
    }
}
void Room::render() const
{
    for (int y = 0; y < height; ++y)
    {

        for (int x = 0; x < width; ++x) 
        {
            if (grid[y][x] == BLOCK)
            {
                // Calculate the position based on the tile size
                float left = x * tileSize;
                float bottom = y * tileSize;
                drawQuad(left, bottom); // Pass the bottom left corner of the quad
            }
        }
    }

}

void Room::drawQuad(float left, float bottom) const 
{
    float right = left + tileSize;
    float top = bottom + tileSize;

    glColor3f(0.5f, 0.5f, 0.5f); // Gray color for the impassable tiles
    glBegin(GL_QUADS);
    glVertex2f(left, bottom); // Bottom left corner
    glVertex2f(right, bottom); // Bottom right corner
    glVertex2f(right, top); // Top right corner
    glVertex2f(left, top); // Top left corner
    glEnd();
}

bool Room::isCellBlocked(int x, int y) const {
    if (x < 0 || x >= width || y < 0 || y >= height) {
        return true; // Out of bounds
    }
    return grid[y][x] == BLOCK;
}
void Room::setTileAsBlocked(int x, int y) {
    if (x >= 0 && x < width && y >= 0 && y < height) {
        grid[y][x] = BLOCK;
    }
}